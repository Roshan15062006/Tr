# FINAL_STATUS — TrustNet AI (NOT production-ready)

Status date: 2026-10-18. This file separates **what was actually executed** from **what was changed but never run**.
Nothing here is claimed as passing unless a command in the "Executed" table produced that result in this session.

## Latest implementation tranche (2026-10-18)

- Added a deterministic Investigator attack-family label and surfaced it in the Agent panel. It classifies only from evidence rules and reports `unknown` when evidence is insufficient; it is not an LSTM and does not directly execute actions.
- Fixed `test_agents.py` login-attempt fixture isolation using UUID attempt IDs, connection closure in `finally`, and clearing stale attempts between tests.
- Corrected demo wording so LSTM and CSI hardware are marked planned, MFA is not represented as implemented, and simulated containment is labelled as a demo.
- Added `backend/test_attack_classifier.py` (5 tests).
- Verification actually executed after these changes: `python -m compileall -q backend` passed; `cd backend && python -m unittest test_core_security test_attack_classifier -v` passed **62 tests**.
- The FastAPI integration suite, frontend type/lint/test/build checks and dependency audits remain unverified. The complete application has not been run end to end. This ZIP is not production-ready.

## Additional implementation (2026-10-18)

- Added `backend/models/request_policy.py` to keep known high-frequency, read-only dashboard polling endpoints out of API request-volume monitoring. Mutating requests and unlisted reads remain monitored.
- Aligned frontend risk-tier thresholds with the documented backend score boundaries (0–30, 31–60, 61–85, 86–100). Frontend runtime/build verification is still blocked by missing npm dependencies.
- Added `backend/test_request_policy.py` with coverage for excluded polls, mutating requests, unlisted reads, and trailing slashes.
- Updated `scripts/verify_all.sh` to include the new request-policy tests.
- Verification: `cd backend && python -m unittest test_request_policy test_core_security test_attack_classifier -q` — **66 tests passed**; `python -m compileall -q .` from `backend/` passed.

## Latest follow-up checks (2026-10-18)

- `cd backend && python -m unittest test_core_security test_attack_classifier test_request_policy -q` — **66 tests passed**.
- The isolated restricted-account WebSocket-ticket regression test passed.
- `cd backend && python -m unittest test_agents -v` could not start: the environment lacks `bcrypt` (`ModuleNotFoundError` at `main.py` import).
- `npm ci --ignore-scripts --offline` could not complete because `@testing-library/dom` is not cached and registry access is unavailable. A comparison of root package dependencies to package-lock root declarations found no missing/extra entries or version mismatches, but this is not a successful clean install.

## Why most of the requested verification could not be run

The session that produced this ZIP had no route to the package registries: the egress proxy answered
`403 CONNECT` (policy denial) for `pypi.org` and `registry.npmjs.org`. That was reported, not worked around.
Consequently these real dependencies were **not installed**: `fastapi`, `httpx`, `websockets`, `bcrypt`, `pytest`,
and every package in `node_modules` (`vite`, `vitest`, `eslint`, `typescript` types for React, …).
No mocks or shims were substituted to claim they passed.

## Executed in this session (Python 3.13.16, PyJWT 2.14.0, numpy 2.5.3, scikit-learn 1.9.1, pandas 3.0.5, SQLite 3.45)

| Command (from project root) | Actual result |
|---|---|
| `python3 -m compileall -q backend` | exit 0 |
| `cd backend && python -m unittest test_core_security -v` | **57 tests, OK** (re-run 5×, all OK, ~6.5 s each) |
| `python3 test_ml_models.py` | exit 0 (synthetic-data smoke checks) |
| `cd backend && python3 evaluate_synthetic.py` | exit 0; seed 42, 1,000 held-out synthetic rows: accuracy 0.994, precision 0.9615, recall 1.0, F1 0.9804. **Synthetic data only — not an operational accuracy claim.** |
| Syntax-only parse of the 3 edited `.tsx` files with TypeScript 6.0.3 `transpileModule` | no syntax errors. **This is not a type-check.** |
| Mutation checks (8 of the fixes reverted one at a time in a scratch copy) | the matching test failed each time, so those tests are sensitive to the bugs they guard |

`test_core_security.py` uses the real production modules, real SQLite files, real threads and real PyJWT. It needs no
FastAPI/bcrypt, so it **does not** exercise HTTP routing, real bcrypt hashing or the WebSocket handshake. It covers:

- **Approvals** — viewer denied (403, audited); self-approval denied; exactly-once execution; 6-way concurrent
  approval → exactly one winner and the rest 409; expiry (closed + audited, and refused by the atomic claim itself);
  crash recovery marks stuck `executing` rows `failed` and never replays enforcement; unexpected enforcement
  errors are recorded as `failed` rather than left `executing`; reject rules; self-reject denied; legacy
  `approve_incident` self/viewer denial; verdict rules; temp-block always needs human approval; protected
  accounts never blocked; kill switch refuses automatic enforcement.
- **Account restrictions** — expiry (read-time, audited), 1–1440 min bounds, no permanent blocks, admin/analyst
  protected, early release, concurrent creation → one active row, legacy duplicate collapse, login denied
  (`account_restricted`), WebSocket ticket denied.
- **Notifications** — per-recipient listing (privacy), per-user unread counts, cross-user mark-read is a no-op,
  dedup + cooldown, concurrent dedup → one row, `skipped` when SMTP absent, SMTP failure keeps record and redacts
  secrets, header-injection stripped.
- **Rate limiter** — limit, sliding window, per-client isolation, key pruning, invalid config fails fast,
  thread-safety, env defaults. (The 429 middleware itself needs FastAPI and was not run.)
- **Audit chain** — verify, row tamper, ledger rewrite, deleted row, out-of-chain insert, append-only triggers,
  concurrent writers stay linear, event validation, pruning cannot break the chain.
- **Auth core** — JWT round-trip, expired/forged/`alg=none`/tampered rejected, logout revocation survives restart,
  WebSocket ticket single-use/expiry/active-user, lockout on repeated unknown-account attempts, password policy,
  RBAC permission matrix, production refuses a missing/short JWT secret and seeds no demo accounts.

## Bugs found by code review and fixed (behaviour verified by the tests above unless marked)

1. **Self-decision gap** — an analyst/admin who is the subject of an incident could `dismiss`/`resolve` it, `reject` the
   response proposed against themselves, or label it via `verdict`. Now 403 + audit entry
   (`response.assert_not_self_target`, `reject`, `submit_verdict`). The HTTP wiring in `main.py` is **not executed** here.
2. **Restriction race** — two concurrent requests could both create an active block. Now enforced by a partial unique
   index, with legacy duplicates collapsed first and the loser returning the winner's record.
3. **Stranded approvals** — an unexpected exception after an approval was claimed left it `executing` until crash recovery.
   Now recorded as `failed` immediately (`approve`, and `temp_block_account` enforcement).
4. **Notification dedup race** — check-then-insert could store duplicates under concurrency. Now serialised by a lock
   (single process only).
5. **`prune_old_events` could permanently break `/api/audit/verify`** (deleted audited rows → `event_missing`). It now
   only removes rows not covered by the chain. It is currently never called by the application.
6. **WebSocket tickets** — expired, never-used tickets accumulated in memory. Now pruned on creation.
7. **WebSocket sessions (UNEXECUTED — needs FastAPI)** — sockets previously outlived logout, deactivation, restriction and the
   token lifetime. Now: re-validated on every client message (the dashboard pings every 30 s), closed on logout,
   and closed after at most the access-token lifetime (30 min).
8. **Frontend credential exposure (UNEXECUTED — needs the frontend toolchain)** — `Overview.tsx` pre-filled the demo
   admin password into form state and three login pages printed demo credentials in all builds. Pre-fill removed;
   hints and the default username now appear only when `import.meta.env.DEV`.
9. **`bcrypt` import is now lazy** in `models/security_auth.py` so password-agnostic logic can be tested without it;
   `main.py` imports `bcrypt` at startup so a deployment without it still fails fast. Authentication logic is unchanged.

Changed-but-not-executed tests: new HTTP/WebSocket tests in `backend/test_agents.py`
(`test_incident_subject_cannot_*`, `test_websocket_*`, `test_notification_endpoints_are_private_per_user`),
a modified self-dismiss assertion in `backend/test_backend_api.py`, and `src/test/authSession.test.ts`.
They compile/parse but have **never been run**; treat any failure there as expected-to-investigate, not as a regression claim.

## NOT verified (requires a machine with network access) — run `scripts/verify_all.sh`

- Backend `test_backend_api` / `test_agents` suites (53 tests previously reported passing by an earlier session; **not re-run**,
  and the earlier session's attempt was cut off by a timeout). The ML-retraining test is slow.
- `npx tsc`, `npm run lint`, `npm test`, `npm run build`. `docs/STATUS.md` previously reported ~60 ESLint errors
  (mostly explicit `any`) — **`npm run lint` is expected to fail until those are fixed** and CI runs it.
  Two earlier-reported TypeScript `key`-prop errors remain unconfirmed.
- **Dependency audits: not run.** `pip-audit` and `npm audit` need advisory data from the registries. A previous session
  reported 16 npm advisories (8 moderate, 6 high, 2 critical); that is **unverified and unfixed**.
  `backend/requirements.txt` is unpinned (no version bounds, no lockfile) — a reproducibility and supply-chain risk.
- **The application was never started** here (no FastAPI), so there is **no end-to-end evidence**: login flow, dashboard,
  incident workflows, live WebSocket and the frontend↔backend integration are untested in this session.
- **Deployment: not attempted** (no hosting access). There is no live URL. `Dockerfile.backend` has not been built.
- Real SMTP delivery, real bcrypt login/lockout through HTTP, browser behaviour.

## Remaining limitations / security issues (honest list)

- Rate limiter is in-memory, per-IP, single-process. It keys on the socket peer address, so behind a reverse proxy all
  clients share one bucket; there is no trusted-proxy handling.
- A restricted/deactivated user's already-open WebSocket stays up until its next message (≤ ~30 s with the shipped
  frontend) — not instant.
- Login timing: unknown accounts skip the bcrypt check, so response time can reveal whether an email exists (the error
  text is generic). Not fixed.
- Local (non-production) mode seeds well-known demo accounts (`admin/admin123`, etc.). Never run it exposed to a network;
  deploy only with `TRUSTNET_ENV=production`.
- Audit chain is local: someone with write access to the database file can rewrite rows *and* recompute hashes, and
  tail truncation is not detectable. Anchor `head_hash` externally for stronger evidence.
- Identity cache, login lockout counters, WebSocket tickets and notification locks are per-process; multi-worker
  deployments need shared state.
- Models are trained on synthetic data; metrics are not operational accuracy.
- `escalate` intentionally has no self-target guard (it only raises scrutiny).
- Two lockfiles (`package-lock.json`, `bun.lockb`) are present; CI uses npm.

## Verdict

**Not production-ready.** The evidence supports only: the security-critical core logic (approvals, expiry, concurrency,
crash recovery, restrictions, notification privacy/dedup, rate-limiter, audit chain, token/ticket handling) passes
57 executed tests against real SQLite. The HTTP layer, frontend, dependency posture, end-to-end behaviour and
deployment remain unverified.

## Latest update — incident correlation (2026-10-18)

Added a configurable incident correlation window (`TRUSTNET_INCIDENT_CORRELATION_MINUTES`, default 30, clamped to 1–1440). Repeated high-risk signals for the same user/device update the existing open incident only inside this window; a later burst creates a separate incident. Three focused tests passed. This does not replace full graph-based correlation and does not auto-resolve older incidents.
