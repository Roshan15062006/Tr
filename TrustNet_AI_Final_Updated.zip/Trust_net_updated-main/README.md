# TrustNet AI

Zero-trust behavioural security demo: React + Vite frontend, FastAPI backend, SQLite storage, ML risk scoring,
an agent layer (Investigator -> Response -> Orchestrator, analyst feedback/learning), tamper-evident audit chain,
notifications, and WebSocket live updates.

> **Status: security-hardened checkpoint, NOT production-ready** (frontend checks, dependency audits and an end-to-end run are still unverified). See `FINAL_STATUS.md` for exactly what was and was not tested.

## Run locally
```bash
# backend (http://localhost:8010)
cd backend
python -m venv .venv && . .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp ../.env.example ../.env                           # then edit; never commit .env
uvicorn main:app --host 127.0.0.1 --port 8010

# frontend (new terminal, project root; http://localhost:8080 or Vite's printed URL)
npm ci
npm run dev
```
Health check: `GET http://localhost:8010/api/health`. The SQLite DB is created automatically at `TRUSTNET_DB_PATH`.
Local demo accounts exist only when `TRUSTNET_ENV` is not `production` (see `backend/models/security_auth.py`).

## Tests
One command (needs network; creates `.venv`, installs everything, runs every check, writes `verification-report.txt`):
```bash
scripts/verify_all.sh
```
Individual commands:
```bash
# backend - core security suite: stdlib only (no FastAPI/bcrypt needed). Verified: 57 tests OK on 2026-10-18.
cd backend && python -m unittest test_core_security -v
# backend - HTTP/agent suites (need the real requirements installed). NOT re-run since the latest changes.
cd backend && python -m unittest test_backend_api test_agents -v
# ML smoke test and synthetic holdout evaluation (verified: exit 0)
python test_ml_models.py && (cd backend && python evaluate_synthetic.py)
# frontend (NOT run in the latest session - no registry access)
npx tsc -p tsconfig.app.json --noEmit && npm run lint && npm test && npm run build
# dependency audits (NOT run)
pip-audit -r backend/requirements.txt && npm audit --audit-level=high
```
See `FINAL_STATUS.md` for exactly which of these were executed and their results.

## Security behaviour implemented
- Approvals: no self-approval (403), only admin/analyst (403), atomic single execution, 409 once decided,
  expiry (`TRUSTNET_APPROVAL_TTL_MINUTES`, default 60), crash recovery of stuck `executing` approvals (marked failed).
  An account can never dismiss, resolve, reject or label an incident/action that targets itself (403, audited).
- Autonomy: kill switch, autonomy mode, hourly cap and protected admin/analyst accounts re-checked immediately before
  automatic execution. Sensitive account actions (`temp_block_account`) always need recorded human approval.
- Account restrictions: expiring temporary blocks (default 30 min, max 24 h, never permanent) enforced in login,
  every authenticated route, and WebSocket tickets; released early via `POST /api/account-restrictions/{id}/release`.
- Notifications: persistent, per-user unread count and mark-read, persistent dedup/cooldown
  (`TRUSTNET_NOTIFY_COOLDOWN_MINUTES`), SMTP failure keeps the in-app record, SMTP secrets redacted.
- Rate limiting: enforced per-IP limiter (429), on by default only when `TRUSTNET_ENV=production`
  (`TRUSTNET_RATE_LIMIT_ENABLED`, `..._API_PER_MIN`, `..._LOGIN_PER_MIN`). In-memory, single-process only.
- Persistent login lockout (existing), security headers and env-based CORS allowlist (existing).
- WebSocket: single-use 60 s tickets; sockets are re-validated on every message, closed on logout and after the
  30-minute access-token lifetime.

## Production notes
Set `TRUSTNET_ENV=production`, a 32+ char `TRUSTNET_JWT_SECRET`, `TRUSTNET_BOOTSTRAP_ADMIN_EMAIL/PASSWORD`, and
`TRUSTNET_CORS_ORIGINS`. Docker: `docker build -f Dockerfile.backend -t trustnet-backend .` (backend only; serve the
built frontend (`npm run build` -> `dist/`) from any static host). No hosted deployment has been performed or verified.
