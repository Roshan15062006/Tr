# TrustNet AI — Project Manifest

## Main folders and files
- `src/` — React + Vite + TypeScript frontend (pages, components, `services/mlBackendService.ts`, memory-only `authSession.ts`).
  - `src/test/` — Vitest tests (`example.test.ts`, `authSession.test.ts` — the latter not yet executed).
- `backend/` — FastAPI app (`main.py`), SQLite persistence, authentication, ML/risk analysis, agents, tests.
  - `backend/agents/` — Investigator, Response (approvals/expiry/recovery), Notifier, Learning, Orchestrator.
  - `backend/models/` — database, security_auth, security_events (audit chain), account_restrictions, rate_limit,
    device_registry, incident_store, risk/ML models, network monitor/topology.
  - `backend/routes/` — API schemas and ML routes.
  - `backend/test_core_security.py` — 57 stdlib-only security tests (executed, OK).
  - `backend/test_backend_api.py`, `backend/test_agents.py` — FastAPI TestClient suites (need real deps; not re-run).
- `scripts/verify_all.sh` — one-command install + full verification + audits (needs network).
- `.github/workflows/ci.yml` — CI: backend tests, frontend checks, dependency-audit job.
- `docs/` — `AGENTS.md` (agent layer), `STATUS.md` (earlier implementation status; see FINAL_STATUS.md for the latest).
- Root docs — `README.md`, `FINAL_STATUS.md` (authoritative verified/unverified status), `HANDOFF_STATUS.md` and
  `ANTIGRAVITY_NEXT_PROMPT.md` (historical hand-off notes), `ML_*.md` / `OPTIMIZED_*.md` (ML notes).
- `test_ml_models.py`, `simulate_attack.py` — ML smoke test and attack simulator.
- `Dockerfile.backend`, `.env.example` — container recipe (unbuilt) and example config (placeholders only).

## Setup
Backend: `cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && uvicorn main:app --host 127.0.0.1 --port 8010`
Frontend (separate terminal, project root): `npm ci && npm run dev`
Copy `.env.example` to `.env` and set values; never commit a real `.env`, tokens or credentials.

## Verification commands (see FINAL_STATUS.md for actual results)
- `scripts/verify_all.sh` (everything), or
- `cd backend && python -m unittest test_core_security test_backend_api test_agents -v`
- `npx tsc -p tsconfig.app.json --noEmit && npm run lint && npm test && npm run build`
- `pip-audit -r backend/requirements.txt && npm audit --audit-level=high`

## Current status
Executed and passing: `compileall`, `test_core_security` (57 tests), ML smoke test, synthetic evaluation.
Not executed (no registry access in the packaging session): FastAPI suites, tsc, ESLint, Vitest, Vite build, dependency
audits, application start-up/end-to-end, deployment. **Not production-ready.**

## Excluded from the ZIP
`.git`, `node_modules`, virtual environments, caches (`__pycache__`, `.pytest_cache`, `dist`), real `.env` files,
credentials and any SQLite database (`*.db`, `*.db-wal`, `*.db-shm`).
