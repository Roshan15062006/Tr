# TrustNet AI — Next Implementation Prompt for Antigravity

Copy the prompt below into Antigravity after opening this extracted project folder. Work on this existing codebase; do not create a replacement project.

---

## MASTER TASK

You are working on the existing TrustNet AI application. The project uses React + Vite, Python FastAPI, SQLite, and existing WebSocket infrastructure. Inspect the repository before changing anything. Preserve working features and existing APIs wherever practical. Do not introduce MongoDB or a Node.js backend. Do not build a disconnected prototype.

### Reported baseline — verify before relying on it

The previous coding session reported that it added SQLite persistence and incident numbering, Investigator rules/tools, a Response agent, analyst feedback/learning, an orchestrator wired into login/risk/incident paths, notifications, audit events, autonomy safeguards, and an Incident Center UI. It reported 53 backend tests passing, one Vitest test passing, and a Vite production build succeeding. It also reported these remaining issues:

- A legacy approval route still permits self-approval (audit-flagged).
- Six TypeScript errors remain in existing components (including PageTransition, Overview, OverviewPage, and IncidentCenterPage).
- Account-level response for incidents without a device is incomplete.
- Dependency advisories have not been resolved.
- Real SMTP delivery was not tested; only a fake transport was used.
- The analyst-learning threshold has not been reached using real data.
- A publicly hosted application URL has not been verified.

These are reports, not guaranteed facts. Verify each against the current code and actual commands/results.

### 1. Establish a safe baseline

1. Inspect the repository tree, README, package.json, backend requirements, routes, database/store code, authentication/RBAC, audit chain, WebSocket authorization, agents, tests, and current Git status if `.git` exists.
2. Do not assume the earlier report is accurate. Identify which items are implemented, partial, missing, or broken.
3. Do not overwrite or delete user data, local databases, secrets, or existing work. Do not print secrets in output.
4. If no Git repository exists, advise creating a backup/branch before risky changes. Do not claim a commit or push unless actually completed.
5. Write a concise checklist, then continue implementing—not just planning.

### 2. Fix approval security first

Inspect every approval and response-execution route, including legacy routes and aliases.

- Prevent a user from approving a security action that targets that same user/account.
- Enforce authorization on the backend; never trust frontend visibility or role flags.
- Require a valid pending approval record before executing actions that require approval.
- Use an atomic state transition so concurrent/repeated decisions cannot execute twice.
- Return HTTP 403 for unauthorized actions and HTTP 409 for already-decided approvals, consistent with existing API conventions.
- Recheck approval state immediately before execution; reject expired approvals.
- Audit request, decision, execution, rejection, and failure.
- Update any tests that expected unsafe behavior; do not preserve a vulnerability merely to keep an old test green.
- Preserve compatible API behavior where it does not compromise security.
- Add tests for self-approval, unauthorized decisions, duplicate/concurrent decisions, expired approvals, and execution without a valid approval.

### 3. Fix frontend TypeScript and quality issues

- Run the repository's actual TypeScript check and inspect each reported error.
- Fix the underlying errors, including those in PageTransition, Overview, OverviewPage, and IncidentCenterPage if they still exist.
- Do not silence errors with broad `any`, blanket `@ts-ignore`, or disabled type checking.
- Run the existing Vitest, Vite production build, and ESLint scripts. Inspect package.json first and use the correct scripts.
- Fix issues introduced by your changes and clearly report unrelated remaining failures.

### 4. Implement safe account-level response if compatible

For suspicious login incidents without a device association, inspect the authentication/session architecture and implement a proportionate account/session restriction only if it can be enforced correctly.

- No permanent account disabling automatically.
- Sensitive account actions require recorded human approval.
- Never automatically lock or block administrator/analyst accounts.
- Enforce restrictions in backend authentication/authorization, not just UI.
- Define expiry, release, and audit behavior.
- Test authorized, unauthorized, expired, and privileged-account cases.
- If the existing architecture cannot support a safe implementation, document the limitation and leave the feature explicitly partial instead of faking it.

### 5. Security and dependency review

- Inspect dependency manifests and lockfiles, then run applicable vulnerability audits using tools available in the environment.
- Identify package name, affected version, severity, direct/transitive status, and recommended compatible fix.
- Do not blindly upgrade all dependencies or break reproducibility.
- Review authentication/token handling, account lockouts and rate limits, CORS allowlist, security headers, input validation, WebSocket ticket/auth checks, audit-chain concurrency and verification, default credentials, and accidental secrets.
- Do not expose secret values. If a secret is found in tracked history, explain that rotation is required; removing it from the current file alone may not be enough.
- Do not claim the app is secure merely because controls exist. Run relevant tests and document limitations.

### 6. Validate the real end-to-end pipeline

Use fictional data only. Do not connect to real enterprise systems or attack external systems.

Verify the real application flow:

Event/login attempt → actual risk score → one persistent correlated incident → read-only Investigator evidence → deterministic Response decision → backend-enforced action or valid approval request → persisted notification → audit entry → analyst verdict → truthful learning result.

Confirm:
- Repeated correlated events do not create duplicate incidents/actions.
- Incidents, agent logs, approvals, notifications, and blocks persist across restart.
- The kill switch prevents new automatic response enforcement.
- Autonomous Mode OFF queues actions for approval.
- Temporary restrictions expire correctly.
- Protected administrator/analyst accounts cannot be automatically blocked.
- ML/model unavailability degrades to deterministic rules rather than crashing.
- WebSocket authorization prevents sensitive data reaching unauthorized clients.
- Frontend live indicators reflect the actual connection state.
- No live UI presents mock/sample data as real activity without labeling it.
- Analyst learning is reported as applied only if the supported baseline/weights actually changed and tests show the result.

Run existing backend tests and the newly relevant tests. The earlier session reported this command, but inspect test layout and use the correct command for this checkout:

`python -m unittest test_backend_api test_agents`

Also run frontend TypeScript, Vitest, build, and lint checks where configured. If a dependency or runtime is unavailable, report the exact command, error, and installation steps. Never claim a check passed unless it actually ran successfully.

### 7. Final delivery

Update README/setup instructions and `.env.example` only as needed. Keep real credentials out of source control. Include exact commands to install dependencies, run backend/frontend, execute tests, and run the fictional demo. If Docker/CI is already present or practical, validate it; do not claim it works without running it.

At completion, report:
1. Files changed and why.
2. Features verified as complete, partial, or not implemented.
3. Exact tests/checks run and actual results.
4. Remaining errors and dependency advisories.
5. Safe commands to run the application.
6. Exact Git commands for committing/pushing, without claiming they were executed unless they were.
7. A hosted URL only if deployment actually occurred and the URL was verified.

Do not stop after the audit. Implement the fixes, run checks, and report honestly.
